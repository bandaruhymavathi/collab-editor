import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PanelLeft, PanelRight, Users } from "lucide-react";
import RichTextEditor from "./rich-text-editor";
import type { DocumentWithCollaborators } from "@shared/schema";

interface DocumentEditorProps {
  document?: DocumentWithCollaborators;
  onContentChange: (content: any) => void;
  onToggleOutline: () => void;
  onToggleProperties: () => void;
}

export default function DocumentEditor({
  document,
  onContentChange,
  onToggleOutline,
  onToggleProperties,
}: DocumentEditorProps) {
  const [activeUsers] = useState([
    { name: "John Doe", initials: "JD", color: "#34A853" },
    { name: "Alice Smith", initials: "AS", color: "#1A73E8" },
  ]);

  const [content, setContent] = useState(
    document?.content || {
      type: "doc",
      content: [
        {
          type: "heading",
          attrs: { level: 1 },
          content: [{ type: "text", text: "Project Proposal: Real-time Collaborative Document Editor" }]
        },
        {
          type: "heading",
          attrs: { level: 2 },
          content: [{ type: "text", text: "Introduction" }]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "This document outlines the development plan for a real-time collaborative document editor that enables multiple users to work simultaneously on shared documents. The platform will provide a seamless editing experience similar to Google Docs with modern web technologies."
            }
          ]
        },
        {
          type: "heading",
          attrs: { level: 3 },
          content: [{ type: "text", text: "Project Overview" }]
        },
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "The collaborative editor will feature real-time synchronization, rich text formatting, and intuitive user interface design. Key capabilities include:"
            }
          ]
        },
        {
          type: "bulletList",
          content: [
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [{ type: "text", text: "Real-time collaborative editing with conflict resolution" }]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [{ type: "text", text: "Rich text formatting (bold, italic, underline, lists, etc.)" }]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [{ type: "text", text: "Document sharing and permission management" }]
                }
              ]
            },
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [{ type: "text", text: "Version history and document recovery" }]
                }
              ]
            },
          ]
        }
      ]
    }
  );

  useEffect(() => {
    if (document?.content) {
      setContent(document.content);
    }
  }, [document?.content]);

  const handleContentChange = (newContent: any) => {
    setContent(newContent);
    onContentChange(newContent);
  };

  return (
    <main className="flex-1 bg-gray-100 overflow-y-auto relative">
      {/* Mobile controls */}
      <div className="lg:hidden flex items-center justify-between p-2 bg-white border-b">
        <Button variant="ghost" size="sm" onClick={onToggleOutline}>
          <PanelLeft className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="sm" onClick={onToggleProperties}>
          <PanelRight className="h-4 w-4" />
        </Button>
      </div>

      <div className="max-w-4xl mx-auto py-8 px-4">
        {/* Document Paper */}
        <div className="bg-white rounded-lg shadow-sm relative min-h-[11in] p-16">
          {/* Collaborative cursors (mock) */}
          <div
            className="absolute w-0.5 h-5 bg-green-500 pointer-events-none z-10"
            style={{ top: "120px", left: "200px" }}
          >
            <div className="absolute -top-6 -left-2 bg-green-500 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
              John Doe
            </div>
          </div>

          <div
            className="absolute w-0.5 h-5 bg-blue-600 pointer-events-none z-10 animate-pulse"
            style={{ top: "300px", left: "150px" }}
          >
            <div className="absolute -top-6 -left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
              Alice Smith
            </div>
          </div>

          {/* Rich Text Editor */}
          <RichTextEditor
            content={content}
            onChange={handleContentChange}
          />
        </div>

        {/* Live collaboration status */}
        <div className="mt-4 text-center">
          <Badge variant="secondary" className="inline-flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <Users className="h-3 w-3" />
            <span>{activeUsers.length + 1} people editing</span>
          </Badge>
        </div>
      </div>
    </main>
  );
}
