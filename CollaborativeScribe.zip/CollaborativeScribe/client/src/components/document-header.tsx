import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { FileText, Share2, Users } from "lucide-react";
import type { DocumentWithCollaborators } from "@shared/schema";

interface DocumentHeaderProps {
  document?: DocumentWithCollaborators;
  onTitleChange: (title: string) => void;
  onShareClick: () => void;
  isSaving: boolean;
}

export default function DocumentHeader({
  document,
  onTitleChange,
  onShareClick,
  isSaving,
}: DocumentHeaderProps) {
  const [title, setTitle] = useState(document?.title || "Untitled Document");

  const handleTitleSubmit = () => {
    if (title !== document?.title) {
      onTitleChange(title);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleTitleSubmit();
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getLastModified = () => {
    if (!document?.updatedAt) return "";
    const now = new Date();
    const updated = new Date(document.updatedAt);
    const diffMs = now.getTime() - updated.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "Last edit was just now";
    if (diffMins === 1) return "Last edit was 1 minute ago";
    if (diffMins < 60) return `Last edit was ${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours === 1) return "Last edit was 1 hour ago";
    if (diffHours < 24) return `Last edit was ${diffHours} hours ago`;
    
    return `Last edit was ${Math.floor(diffHours / 24)} days ago`;
  };

  return (
    <header className="bg-white border-b border-gray-200 h-14 flex items-center px-4 relative z-50">
      <div className="flex items-center space-x-4 flex-1">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <FileText className="h-4 w-4 text-white" />
          </div>
          <span className="font-medium text-gray-700 hidden sm:block">DocSpace</span>
        </div>

        {/* Document Title */}
        <div className="flex-1 max-w-md">
          <Input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onBlur={handleTitleSubmit}
            onKeyPress={handleKeyPress}
            className="text-lg font-normal border-none bg-transparent px-2 py-1 focus:bg-white focus:border focus:border-blue-600 focus:rounded"
          />
          <div className="text-xs text-gray-500 px-2">
            {isSaving ? "Saving..." : getLastModified()}
          </div>
        </div>
      </div>

      {/* Right side controls */}
      <div className="flex items-center space-x-2">
        {/* Collaboration indicators */}
        {document && document.collaborators.length > 0 && (
          <div className="flex items-center space-x-1">
            <div className="flex -space-x-2">
              {document.collaborators.slice(0, 3).map((collaborator) => (
                <Avatar key={collaborator.id} className="w-8 h-8 border-2 border-white">
                  <AvatarFallback className="text-xs font-medium bg-green-500 text-white">
                    {getInitials(collaborator.user.name)}
                  </AvatarFallback>
                </Avatar>
              ))}
              {document.collaborators.length > 3 && (
                <Avatar className="w-8 h-8 border-2 border-white">
                  <AvatarFallback className="text-xs font-medium bg-yellow-500 text-white">
                    +{document.collaborators.length - 3}
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          </div>
        )}

        {/* Share button */}
        <Button
          onClick={onShareClick}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full text-sm font-medium"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Share
        </Button>

        {/* User menu */}
        <Avatar className="w-8 h-8 cursor-pointer">
          <AvatarFallback className="bg-blue-600 text-white font-medium">
            ME
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
