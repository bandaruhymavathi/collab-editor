import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, X } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { DocumentWithCollaborators } from "@shared/schema";

interface DocumentOutlineProps {
  document?: DocumentWithCollaborators;
  onClose: () => void;
}

export default function DocumentOutline({ document, onClose }: DocumentOutlineProps) {
  // Mock outline structure based on document content
  const outline = [
    { title: "Introduction", level: 2, id: "intro" },
    { title: "Project Overview", level: 3, id: "overview" },
    { title: "Technical Requirements", level: 2, id: "tech" },
    { title: "Frontend Stack", level: 3, id: "frontend" },
    { title: "Backend Architecture", level: 3, id: "backend" },
    { title: "Timeline & Milestones", level: 2, id: "timeline" },
    { title: "Conclusion", level: 2, id: "conclusion" },
  ];

  const comments = document?.comments || [];

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getTimeAgo = (date: string | Date) => {
    const now = new Date();
    const past = new Date(date);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="text-sm font-medium text-gray-700">Document outline</h3>
        <Button variant="ghost" size="sm" onClick={onClose} className="lg:hidden">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-1">
        {/* Outline */}
        <div className="p-4">
          <div className="space-y-2">
            {outline.map((heading, index) => (
              <div
                key={index}
                className={`text-sm text-gray-600 hover:text-blue-600 cursor-pointer py-1 ${
                  heading.level === 3 ? "pl-4" : ""
                }`}
              >
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-gray-400 rounded-full mr-2"></div>
                  {heading.title}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Comments Section */}
        <div className="border-t border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
            <MessageSquare className="h-4 w-4 mr-2 text-gray-500" />
            Comments
          </h3>
          
          {comments.length === 0 ? (
            <div className="text-sm text-gray-500">No comments yet</div>
          ) : (
            <div className="space-y-3">
              {comments.map((comment) => (
                <div key={comment.id} className="bg-gray-50 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <Avatar className="w-6 h-6">
                      <AvatarFallback className="text-xs font-medium bg-green-500 text-white">
                        {getInitials(comment.user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="text-xs text-gray-500 mb-1">
                        {comment.user.name} • {getTimeAgo(comment.createdAt)}
                      </div>
                      <div className="text-sm text-gray-700">{comment.content}</div>
                      <Button variant="link" className="text-xs text-blue-600 p-0 h-auto mt-1">
                        Reply
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </aside>
  );
}
