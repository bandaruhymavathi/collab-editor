import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MoreVertical, X, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { DocumentWithCollaborators } from "@shared/schema";

interface DocumentPropertiesProps {
  document?: DocumentWithCollaborators;
  onClose: () => void;
}

export default function DocumentProperties({ document, onClose }: DocumentPropertiesProps) {
  const { toast } = useToast();

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatTime = (date: string | Date) => {
    return new Date(date).toLocaleString("en-US", {
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  const handleCopyLink = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    toast({
      title: "Link copied",
      description: "Document link copied to clipboard",
    });
  };

  // Mock version history
  const versionHistory = [
    { date: new Date(), editor: "Current version", isCurrent: true },
    { date: new Date(Date.now() - 39 * 60 * 1000), editor: "Alice Smith", isCurrent: false },
    { date: new Date(Date.now() - 94 * 60 * 1000), editor: "John Doe", isCurrent: false },
  ];

  // Mock word count
  const wordCount = document ? "1,247 words" : "0 words";

  return (
    <aside className="w-80 bg-white border-l border-gray-200 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="text-sm font-medium text-gray-700">Document Properties</h3>
        <Button variant="ghost" size="sm" onClick={onClose} className="xl:hidden">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4">
          {/* Document info */}
          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Created</label>
              <div className="text-sm text-gray-900">
                {document ? formatDate(document.createdAt) : "—"}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Last Modified</label>
              <div className="text-sm text-gray-900">
                {document ? formatTime(document.updatedAt) : "—"}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Word Count</label>
              <div className="text-sm text-gray-900">{wordCount}</div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Owner</label>
              <div className="flex items-center space-x-2">
                <Avatar className="w-6 h-6">
                  <AvatarFallback className="text-xs font-medium bg-blue-600 text-white">
                    {document ? getInitials(document.owner.name) : "ME"}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm text-gray-900">
                  {document ? document.owner.name : "Me"}
                </span>
              </div>
            </div>
          </div>

          {/* Sharing settings */}
          <div className="border-t border-gray-200 pt-4 mb-6">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Sharing</h4>
            <div className="space-y-3">
              {/* Current collaborators */}
              {document && document.collaborators.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-2">
                    People with access
                  </label>
                  <div className="space-y-2">
                    {document.collaborators.map((collaborator) => (
                      <div key={collaborator.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="text-xs font-medium bg-green-500 text-white">
                              {getInitials(collaborator.user.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-sm text-gray-900">{collaborator.user.name}</div>
                            <div className="text-xs text-gray-500 capitalize">
                              {collaborator.permission}
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="p-1">
                          <MoreVertical className="h-4 w-4 text-gray-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Share link */}
              <div>
                <Button
                  onClick={handleCopyLink}
                  variant="outline"
                  className="w-full flex items-center justify-center space-x-2"
                >
                  <Copy className="h-4 w-4 text-gray-500" />
                  <span>Copy link</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Version history */}
          <div className="border-t border-gray-200 pt-4">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Version History</h4>
            <div className="space-y-2">
              {versionHistory.map((version, index) => (
                <div
                  key={index}
                  className="text-sm text-gray-600 hover:text-blue-600 cursor-pointer py-1"
                >
                  <div className="font-medium">{formatTime(version.date)}</div>
                  <div className="text-xs text-gray-500">
                    {version.isCurrent ? "Current version" : version.editor}
                  </div>
                </div>
              ))}
            </div>
            <Button variant="link" className="text-sm text-blue-600 p-0 mt-2">
              See all versions
            </Button>
          </div>
        </div>
      </ScrollArea>
    </aside>
  );
}
