import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Undo,
  Redo,
  PrinterCheck,
  ZoomIn,
  ZoomOut,
  Bold,
  Italic,
  Underline,
  Palette,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  Link,
  Image,
  Table,
  Minus,
  Plus,
} from "lucide-react";
import { useState } from "react";

export default function DocumentToolbar() {
  const [zoom, setZoom] = useState(100);
  const [fontFamily, setFontFamily] = useState("roboto");
  const [fontSize, setFontSize] = useState("16");
  const [activeFormats, setActiveFormats] = useState<Set<string>>(new Set());

  const handleZoomIn = () => {
    setZoom(Math.min(200, zoom + 10));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(50, zoom - 10));
  };

  const toggleFormat = (format: string) => {
    const newFormats = new Set(activeFormats);
    if (newFormats.has(format)) {
      newFormats.delete(format);
    } else {
      newFormats.add(format);
    }
    setActiveFormats(newFormats);
  };

  const isActive = (format: string) => activeFormats.has(format);

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2">
      <div className="flex items-center space-x-1 overflow-x-auto">
        {/* File operations */}
        <div className="flex items-center space-x-1 pr-3">
          <Button variant="ghost" size="sm" className="p-2">
            <Undo className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <Redo className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <PrinterCheck className="h-4 w-4" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Zoom controls */}
        <div className="flex items-center space-x-2 px-3">
          <Button variant="ghost" size="sm" className="p-1" onClick={handleZoomOut}>
            <ZoomOut className="h-3 w-3" />
          </Button>
          <span className="text-sm text-gray-600 min-w-12 text-center">{zoom}%</span>
          <Button variant="ghost" size="sm" className="p-1" onClick={handleZoomIn}>
            <ZoomIn className="h-3 w-3" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Text formatting */}
        <div className="flex items-center space-x-1 px-3">
          <Select value={fontFamily} onValueChange={setFontFamily}>
            <SelectTrigger className="w-32 h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="roboto">Roboto</SelectItem>
              <SelectItem value="arial">Arial</SelectItem>
              <SelectItem value="times">Times New Roman</SelectItem>
              <SelectItem value="helvetica">Helvetica</SelectItem>
            </SelectContent>
          </Select>

          <Select value={fontSize} onValueChange={setFontSize}>
            <SelectTrigger className="w-16 h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="11">11</SelectItem>
              <SelectItem value="12">12</SelectItem>
              <SelectItem value="14">14</SelectItem>
              <SelectItem value="16">16</SelectItem>
              <SelectItem value="18">18</SelectItem>
              <SelectItem value="24">24</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Format controls */}
        <div className="flex items-center space-x-1 px-3">
          <Button
            variant={isActive("bold") ? "secondary" : "ghost"}
            size="sm"
            className="p-2 font-bold"
            onClick={() => toggleFormat("bold")}
          >
            B
          </Button>
          <Button
            variant={isActive("italic") ? "secondary" : "ghost"}
            size="sm"
            className="p-2 italic"
            onClick={() => toggleFormat("italic")}
          >
            I
          </Button>
          <Button
            variant={isActive("underline") ? "secondary" : "ghost"}
            size="sm"
            className="p-2 underline"
            onClick={() => toggleFormat("underline")}
          >
            U
          </Button>
          <Button variant="ghost" size="sm" className="p-2 relative">
            <Palette className="h-4 w-4" />
            <div className="w-4 h-1 bg-gray-900 absolute bottom-1 left-1/2 transform -translate-x-1/2"></div>
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Alignment */}
        <div className="flex items-center space-x-1 px-3">
          <Button variant="ghost" size="sm" className="p-2">
            <AlignLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <AlignCenter className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <AlignRight className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <AlignJustify className="h-4 w-4" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Lists */}
        <div className="flex items-center space-x-1 px-3">
          <Button variant="ghost" size="sm" className="p-2">
            <List className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <ListOrdered className="h-4 w-4" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Insert */}
        <div className="flex items-center space-x-1 px-3">
          <Button variant="ghost" size="sm" className="p-2">
            <Link className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <Image className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <Table className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
