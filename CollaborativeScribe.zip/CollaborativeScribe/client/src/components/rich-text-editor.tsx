import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

interface RichTextEditorProps {
  content: any;
  onChange: (content: any) => void;
  className?: string;
}

export default function RichTextEditor({ content, onChange, className }: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);

  // Convert JSON content to HTML for display
  const renderContent = (node: any): string => {
    if (!node) return "";

    switch (node.type) {
      case "doc":
        return node.content?.map(renderContent).join("") || "";
      
      case "heading":
        const level = node.attrs?.level || 1;
        const headingContent = node.content?.map(renderContent).join("") || "";
        return `<h${level} class="${getHeadingClass(level)}">${headingContent}</h${level}>`;
      
      case "paragraph":
        const paragraphContent = node.content?.map(renderContent).join("") || "";
        return `<p class="mb-4">${paragraphContent}</p>`;
      
      case "bulletList":
        const listItems = node.content?.map(renderContent).join("") || "";
        return `<ul class="list-disc pl-6 mb-4 space-y-2">${listItems}</ul>`;
      
      case "orderedList":
        const orderedItems = node.content?.map(renderContent).join("") || "";
        return `<ol class="list-decimal pl-6 mb-4 space-y-2">${orderedItems}</ol>`;
      
      case "listItem":
        const itemContent = node.content?.map(renderContent).join("") || "";
        return `<li>${itemContent}</li>`;
      
      case "text":
        let text = node.text || "";
        if (node.marks) {
          node.marks.forEach((mark: any) => {
            switch (mark.type) {
              case "bold":
                text = `<strong>${text}</strong>`;
                break;
              case "italic":
                text = `<em>${text}</em>`;
                break;
              case "underline":
                text = `<u>${text}</u>`;
                break;
            }
          });
        }
        return text;
      
      case "blockquote":
        const quoteContent = node.content?.map(renderContent).join("") || "";
        return `<blockquote class="border-l-4 border-blue-600 bg-blue-50 p-4 mb-4 italic">${quoteContent}</blockquote>`;
      
      default:
        return node.content?.map(renderContent).join("") || "";
    }
  };

  const getHeadingClass = (level: number): string => {
    switch (level) {
      case 1:
        return "text-3xl font-bold mb-6 text-gray-900";
      case 2:
        return "text-xl font-semibold mb-4 text-gray-800";
      case 3:
        return "text-lg font-semibold mb-3 text-gray-800";
      default:
        return "text-base font-semibold mb-2 text-gray-800";
    }
  };

  // Update editor content when prop changes
  useEffect(() => {
    if (editorRef.current) {
      const html = renderContent(content);
      editorRef.current.innerHTML = html;
    }
  }, [content]);

  // Handle basic text editing
  const handleInput = () => {
    if (!editorRef.current) return;

    // For now, we'll create a simple text-based update
    // In a real implementation, this would parse the HTML back to JSON
    const textContent = editorRef.current.textContent || "";
    
    // Create a simple paragraph-based structure
    const paragraphs = textContent.split('\n').filter(p => p.trim());
    const newContent = {
      type: "doc",
      content: paragraphs.map(text => ({
        type: "paragraph",
        content: [{ type: "text", text }]
      }))
    };

    onChange(newContent);
  };

  // Handle keyboard shortcuts
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case "b":
          e.preventDefault();
          document.execCommand("bold");
          break;
        case "i":
          e.preventDefault();
          document.execCommand("italic");
          break;
        case "u":
          e.preventDefault();
          document.execCommand("underline");
          break;
      }
    }
  };

  return (
    <div
      ref={editorRef}
      contentEditable
      suppressContentEditableWarning
      onInput={handleInput}
      onKeyDown={handleKeyDown}
      className={cn(
        "outline-none focus:outline-none min-h-96 font-roboto text-gray-900 leading-relaxed",
        "prose prose-lg max-w-none",
        "[&>h1]:text-3xl [&>h1]:font-bold [&>h1]:mb-6 [&>h1]:text-gray-900",
        "[&>h2]:text-xl [&>h2]:font-semibold [&>h2]:mb-4 [&>h2]:text-gray-800",
        "[&>h3]:text-lg [&>h3]:font-semibold [&>h3]:mb-3 [&>h3]:text-gray-800",
        "[&>p]:mb-4",
        "[&>ul]:list-disc [&>ul]:pl-6 [&>ul]:mb-4 [&>ul]:space-y-2",
        "[&>ol]:list-decimal [&>ol]:pl-6 [&>ol]:mb-4 [&>ol]:space-y-2",
        "[&>blockquote]:border-l-4 [&>blockquote]:border-blue-600 [&>blockquote]:bg-blue-50 [&>blockquote]:p-4 [&>blockquote]:mb-4 [&>blockquote]:italic",
        className
      )}
      style={{ lineHeight: 1.6 }}
    />
  );
}
