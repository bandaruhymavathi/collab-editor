import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import type { DocumentWithCollaborators } from "@shared/schema";

interface ShareDialogProps {
  document?: DocumentWithCollaborators;
  isOpen: boolean;
  onClose: () => void;
}

export default function ShareDialog({ document, isOpen, onClose }: ShareDialogProps) {
  const [email, setEmail] = useState("");
  const [permission, setPermission] = useState("viewer");
  const { toast } = useToast();

  const shareLink = document ? `${window.location.origin}/documents/${document.id}` : "";

  const addCollaboratorMutation = useMutation({
    mutationFn: async ({ email, permission }: { email: string; permission: string }) => {
      if (!document) throw new Error("No document");
      const response = await apiRequest("POST", `/api/documents/${document.id}/collaborators`, {
        email,
        permission,
      });
      return response.json();
    },
    onSuccess: () => {
      setEmail("");
      setPermission("viewer");
      queryClient.invalidateQueries({ queryKey: [`/api/documents/${document?.id}`] });
      toast({
        title: "Collaborator added",
        description: "The person has been added to the document",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add collaborator",
        variant: "destructive",
      });
    },
  });

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink);
    toast({
      title: "Link copied",
      description: "Share link copied to clipboard",
    });
  };

  const handleSendInvite = () => {
    if (!email.trim()) {
      toast({
        title: "Email required",
        description: "Please enter an email address",
        variant: "destructive",
      });
      return;
    }

    addCollaboratorMutation.mutate({ email: email.trim(), permission });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Share "{document?.title || "Document"}"</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Link sharing */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2 block">
              Share with link
            </Label>
            <div className="flex space-x-2">
              <Input
                type="text"
                value={shareLink}
                readOnly
                className="flex-1 bg-gray-50 text-sm text-gray-600"
              />
              <Button onClick={handleCopyLink} className="px-4">
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <Select defaultValue="edit">
              <SelectTrigger className="mt-2 w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="edit">Anyone with the link can edit</SelectItem>
                <SelectItem value="comment">Anyone with the link can comment</SelectItem>
                <SelectItem value="view">Anyone with the link can view</SelectItem>
                <SelectItem value="restricted">Restricted</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Invite people */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2 block">
              Invite people
            </Label>
            <div className="flex space-x-2">
              <Input
                type="email"
                placeholder="Enter email addresses"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1"
                onKeyPress={(e) => e.key === "Enter" && handleSendInvite()}
              />
              <Select value={permission} onValueChange={setPermission}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="editor">Editor</SelectItem>
                  <SelectItem value="commenter">Commenter</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={handleSendInvite}
              disabled={addCollaboratorMutation.isPending}
              className="mt-2"
            >
              {addCollaboratorMutation.isPending ? "Sending..." : "Send"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
