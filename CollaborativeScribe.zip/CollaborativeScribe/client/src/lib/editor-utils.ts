// Utility functions for the rich text editor

export interface EditorNode {
  type: string;
  content?: EditorNode[];
  attrs?: Record<string, any>;
  marks?: EditorMark[];
  text?: string;
}

export interface EditorMark {
  type: string;
  attrs?: Record<string, any>;
}

export interface EditorContent {
  type: "doc";
  content: EditorNode[];
}

// Convert HTML element to editor JSON
export function htmlToEditorJson(element: HTMLElement): EditorNode | null {
  const tagName = element.tagName.toLowerCase();
  
  switch (tagName) {
    case "h1":
    case "h2":
    case "h3":
    case "h4":
    case "h5":
    case "h6":
      return {
        type: "heading",
        attrs: { level: parseInt(tagName[1]) },
        content: getTextContent(element),
      };
    
    case "p":
      return {
        type: "paragraph",
        content: getTextContent(element),
      };
    
    case "ul":
      return {
        type: "bulletList",
        content: Array.from(element.children).map(child => htmlToEditorJson(child as HTMLElement)).filter(Boolean) as EditorNode[],
      };
    
    case "ol":
      return {
        type: "orderedList",
        content: Array.from(element.children).map(child => htmlToEditorJson(child as HTMLElement)).filter(Boolean) as EditorNode[],
      };
    
    case "li":
      return {
        type: "listItem",
        content: getTextContent(element),
      };
    
    case "blockquote":
      return {
        type: "blockquote",
        content: getTextContent(element),
      };
    
    default:
      return null;
  }
}

// Extract text content with formatting marks
function getTextContent(element: HTMLElement): EditorNode[] {
  const result: EditorNode[] = [];
  
  for (const node of element.childNodes) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent || "";
      if (text.trim()) {
        result.push({
          type: "text",
          text,
        });
      }
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      const marks = getMarksFromElement(el);
      const text = el.textContent || "";
      
      if (text.trim()) {
        result.push({
          type: "text",
          text,
          marks: marks.length > 0 ? marks : undefined,
        });
      }
    }
  }
  
  return result;
}

// Extract formatting marks from HTML element
function getMarksFromElement(element: HTMLElement): EditorMark[] {
  const marks: EditorMark[] = [];
  const tagName = element.tagName.toLowerCase();
  
  switch (tagName) {
    case "strong":
    case "b":
      marks.push({ type: "bold" });
      break;
    case "em":
    case "i":
      marks.push({ type: "italic" });
      break;
    case "u":
      marks.push({ type: "underline" });
      break;
  }
  
  return marks;
}

// Convert editor JSON to HTML string
export function editorJsonToHtml(content: EditorContent): string {
  return content.content.map(nodeToHtml).join("");
}

function nodeToHtml(node: EditorNode): string {
  switch (node.type) {
    case "heading":
      const level = node.attrs?.level || 1;
      const headingContent = node.content?.map(nodeToHtml).join("") || "";
      return `<h${level}>${headingContent}</h${level}>`;
    
    case "paragraph":
      const paragraphContent = node.content?.map(nodeToHtml).join("") || "";
      return `<p>${paragraphContent}</p>`;
    
    case "bulletList":
      const listItems = node.content?.map(nodeToHtml).join("") || "";
      return `<ul>${listItems}</ul>`;
    
    case "orderedList":
      const orderedItems = node.content?.map(nodeToHtml).join("") || "";
      return `<ol>${orderedItems}</ol>`;
    
    case "listItem":
      const itemContent = node.content?.map(nodeToHtml).join("") || "";
      return `<li>${itemContent}</li>`;
    
    case "blockquote":
      const quoteContent = node.content?.map(nodeToHtml).join("") || "";
      return `<blockquote>${quoteContent}</blockquote>`;
    
    case "text":
      let text = node.text || "";
      if (node.marks) {
        node.marks.forEach(mark => {
          switch (mark.type) {
            case "bold":
              text = `<strong>${text}</strong>`;
              break;
            case "italic":
              text = `<em>${text}</em>`;
              break;
            case "underline":
              text = `<u>${text}</u>`;
              break;
          }
        });
      }
      return text;
    
    default:
      return "";
  }
}

// Generate document outline from content
export function generateOutline(content: EditorContent): Array<{ title: string; level: number; id: string }> {
  const outline: Array<{ title: string; level: number; id: string }> = [];
  
  content.content.forEach((node, index) => {
    if (node.type === "heading" && node.content) {
      const title = node.content
        .filter(child => child.type === "text")
        .map(child => child.text)
        .join("");
      
      if (title.trim()) {
        outline.push({
          title: title.trim(),
          level: node.attrs?.level || 1,
          id: `heading-${index}`,
        });
      }
    }
  });
  
  return outline;
}

// Calculate word count from editor content
export function calculateWordCount(content: EditorContent): number {
  let wordCount = 0;
  
  function countWordsInNode(node: EditorNode): void {
    if (node.type === "text" && node.text) {
      const words = node.text.trim().split(/\s+/).filter(word => word.length > 0);
      wordCount += words.length;
    }
    
    if (node.content) {
      node.content.forEach(countWordsInNode);
    }
  }
  
  content.content.forEach(countWordsInNode);
  return wordCount;
}
