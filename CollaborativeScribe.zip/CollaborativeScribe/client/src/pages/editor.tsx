import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import DocumentHeader from "@/components/document-header";
import DocumentToolbar from "@/components/document-toolbar";
import DocumentEditor from "@/components/document-editor";
import DocumentOutline from "@/components/document-outline";
import DocumentProperties from "@/components/document-properties";
import ShareDialog from "@/components/share-dialog";
import { useToast } from "@/hooks/use-toast";
import type { DocumentWithCollaborators } from "@shared/schema";

export default function Editor() {
  const { id } = useParams();
  const documentId = id ? parseInt(id) : null;
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [outlinePanelOpen, setOutlinePanelOpen] = useState(true);
  const [propertiesPanelOpen, setPropertiesPanelOpen] = useState(true);
  const { toast } = useToast();

  // Create new document if no ID provided
  const createDocumentMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/documents", {
        title: "Untitled Document",
        content: { type: "doc", content: [] },
        isPublic: false
      });
      return response.json();
    },
    onSuccess: (newDocument) => {
      window.history.replaceState(null, "", `/documents/${newDocument.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create document",
        variant: "destructive",
      });
    },
  });

  // Fetch document data
  const { data: document, isLoading } = useQuery<DocumentWithCollaborators>({
    queryKey: documentId ? [`/api/documents/${documentId}`] : [],
    enabled: !!documentId,
  });

  // Create document on mount if no ID
  useEffect(() => {
    if (!documentId && !createDocumentMutation.isPending) {
      createDocumentMutation.mutate();
    }
  }, [documentId]);

  // Update document mutation
  const updateDocumentMutation = useMutation({
    mutationFn: async (updates: { title?: string; content?: any }) => {
      if (!documentId) throw new Error("No document ID");
      const response = await apiRequest("PATCH", `/api/documents/${documentId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/documents/${documentId}`] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save document",
        variant: "destructive",
      });
    },
  });

  // Handle document title change
  const handleTitleChange = (title: string) => {
    updateDocumentMutation.mutate({ title });
  };

  // Handle document content change
  const handleContentChange = (content: any) => {
    updateDocumentMutation.mutate({ content });
  };

  // Handle responsive panel toggles
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1280) {
        setPropertiesPanelOpen(false);
      }
      if (window.innerWidth < 1024) {
        setOutlinePanelOpen(false);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  if (isLoading || createDocumentMutation.isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-lg">Loading document...</div>
      </div>
    );
  }

  if (!document && documentId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-lg text-red-600">Document not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <DocumentHeader
        document={document}
        onTitleChange={handleTitleChange}
        onShareClick={() => setIsShareDialogOpen(true)}
        isSaving={updateDocumentMutation.isPending}
      />
      
      <DocumentToolbar />
      
      <div className="flex flex-1 h-[calc(100vh-112px)]">
        {outlinePanelOpen && (
          <DocumentOutline
            document={document}
            onClose={() => setOutlinePanelOpen(false)}
          />
        )}
        
        <DocumentEditor
          document={document}
          onContentChange={handleContentChange}
          onToggleOutline={() => setOutlinePanelOpen(!outlinePanelOpen)}
          onToggleProperties={() => setPropertiesPanelOpen(!propertiesPanelOpen)}
        />
        
        {propertiesPanelOpen && (
          <DocumentProperties
            document={document}
            onClose={() => setPropertiesPanelOpen(false)}
          />
        )}
      </div>

      <ShareDialog
        document={document}
        isOpen={isShareDialogOpen}
        onClose={() => setIsShareDialogOpen(false)}
      />
    </div>
  );
}
