import { 
  users, 
  documents, 
  documentCollaborators, 
  documentComments,
  type User, 
  type InsertUser,
  type Document,
  type InsertDocument,
  type DocumentCollaborator,
  type InsertCollaborator,
  type DocumentComment,
  type InsertComment,
  type DocumentWithCollaborators
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Documents
  getDocument(id: number): Promise<Document | undefined>;
  getDocumentWithCollaborators(id: number): Promise<DocumentWithCollaborators | undefined>;
  getDocumentsByUser(userId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, updates: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;

  // Collaborators
  addCollaborator(collaborator: InsertCollaborator): Promise<DocumentCollaborator>;
  getDocumentCollaborators(documentId: number): Promise<(DocumentCollaborator & { user: User })[]>;
  updateCollaboratorPermission(documentId: number, userId: number, permission: string): Promise<boolean>;
  removeCollaborator(documentId: number, userId: number): Promise<boolean>;

  // Comments
  getDocumentComments(documentId: number): Promise<(DocumentComment & { user: User })[]>;
  createComment(comment: InsertComment): Promise<DocumentComment>;
  updateComment(id: number, content: string): Promise<DocumentComment | undefined>;
  deleteComment(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private documents: Map<number, Document>;
  private collaborators: Map<number, DocumentCollaborator>;
  private comments: Map<number, DocumentComment>;
  private currentUserId: number;
  private currentDocumentId: number;
  private currentCollaboratorId: number;
  private currentCommentId: number;

  constructor() {
    this.users = new Map();
    this.documents = new Map();
    this.collaborators = new Map();
    this.comments = new Map();
    this.currentUserId = 1;
    this.currentDocumentId = 1;
    this.currentCollaboratorId = 1;
    this.currentCommentId = 1;

    // Create a default user
    this.createUser({
      username: "demo_user",
      email: "demo@example.com",
      name: "Demo User",
      avatar: undefined
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
    };
    this.users.set(id, user);
    return user;
  }

  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentWithCollaborators(id: number): Promise<DocumentWithCollaborators | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;

    const owner = this.users.get(document.ownerId);
    if (!owner) return undefined;

    const collaborators = Array.from(this.collaborators.values())
      .filter(c => c.documentId === id)
      .map(c => {
        const user = this.users.get(c.userId);
        return user ? { ...c, user } : null;
      })
      .filter(Boolean) as (DocumentCollaborator & { user: User })[];

    const comments = Array.from(this.comments.values())
      .filter(c => c.documentId === id)
      .map(c => {
        const user = this.users.get(c.userId);
        return user ? { ...c, user } : null;
      })
      .filter(Boolean) as (DocumentComment & { user: User })[];

    return {
      ...document,
      owner,
      collaborators,
      comments
    };
  }

  async getDocumentsByUser(userId: number): Promise<Document[]> {
    const ownedDocs = Array.from(this.documents.values()).filter(doc => doc.ownerId === userId);
    const collaboratedDocs = Array.from(this.collaborators.values())
      .filter(c => c.userId === userId)
      .map(c => this.documents.get(c.documentId))
      .filter(Boolean) as Document[];
    
    const allDocs = [...ownedDocs, ...collaboratedDocs];
    const uniqueDocs = Array.from(new Map(allDocs.map(doc => [doc.id, doc])).values());
    
    return uniqueDocs.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const now = new Date();
    const document: Document = {
      ...insertDocument,
      id,
      createdAt: now,
      updatedAt: now,
      shareLink: null
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: number, updates: Partial<InsertDocument>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;

    const updatedDocument: Document = {
      ...document,
      ...updates,
      updatedAt: new Date()
    };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    const deleted = this.documents.delete(id);
    // Clean up related data
    Array.from(this.collaborators.entries()).forEach(([key, collab]) => {
      if (collab.documentId === id) {
        this.collaborators.delete(key);
      }
    });
    Array.from(this.comments.entries()).forEach(([key, comment]) => {
      if (comment.documentId === id) {
        this.comments.delete(key);
      }
    });
    return deleted;
  }

  // Collaborator methods
  async addCollaborator(insertCollaborator: InsertCollaborator): Promise<DocumentCollaborator> {
    const id = this.currentCollaboratorId++;
    const collaborator: DocumentCollaborator = {
      ...insertCollaborator,
      id,
      addedAt: new Date()
    };
    this.collaborators.set(id, collaborator);
    return collaborator;
  }

  async getDocumentCollaborators(documentId: number): Promise<(DocumentCollaborator & { user: User })[]> {
    return Array.from(this.collaborators.values())
      .filter(c => c.documentId === documentId)
      .map(c => {
        const user = this.users.get(c.userId);
        return user ? { ...c, user } : null;
      })
      .filter(Boolean) as (DocumentCollaborator & { user: User })[];
  }

  async updateCollaboratorPermission(documentId: number, userId: number, permission: string): Promise<boolean> {
    const collaborator = Array.from(this.collaborators.values())
      .find(c => c.documentId === documentId && c.userId === userId);
    
    if (!collaborator) return false;

    collaborator.permission = permission;
    return true;
  }

  async removeCollaborator(documentId: number, userId: number): Promise<boolean> {
    const entries = Array.from(this.collaborators.entries());
    const entry = entries.find(([, c]) => c.documentId === documentId && c.userId === userId);
    
    if (!entry) return false;

    return this.collaborators.delete(entry[0]);
  }

  // Comment methods
  async getDocumentComments(documentId: number): Promise<(DocumentComment & { user: User })[]> {
    return Array.from(this.comments.values())
      .filter(c => c.documentId === documentId)
      .map(c => {
        const user = this.users.get(c.userId);
        return user ? { ...c, user } : null;
      })
      .filter(Boolean) as (DocumentComment & { user: User })[];
  }

  async createComment(insertComment: InsertComment): Promise<DocumentComment> {
    const id = this.currentCommentId++;
    const now = new Date();
    const comment: DocumentComment = {
      ...insertComment,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.comments.set(id, comment);
    return comment;
  }

  async updateComment(id: number, content: string): Promise<DocumentComment | undefined> {
    const comment = this.comments.get(id);
    if (!comment) return undefined;

    comment.content = content;
    comment.updatedAt = new Date();
    return comment;
  }

  async deleteComment(id: number): Promise<boolean> {
    return this.comments.delete(id);
  }
}

export const storage = new MemStorage();
