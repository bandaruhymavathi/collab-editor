import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  avatar: text("avatar"),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: jsonb("content").notNull().default('{"type":"doc","content":[]}'),
  ownerId: integer("owner_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  isPublic: boolean("is_public").notNull().default(false),
  shareLink: text("share_link").unique(),
});

export const documentCollaborators = pgTable("document_collaborators", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  userId: integer("user_id").notNull(),
  permission: text("permission").notNull().default("viewer"), // viewer, commenter, editor
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

export const documentComments = pgTable("document_comments", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  position: jsonb("position"), // cursor position for inline comments
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  name: true,
  avatar: true,
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  title: true,
  content: true,
  ownerId: true,
  isPublic: true,
});

export const insertCollaboratorSchema = createInsertSchema(documentCollaborators).pick({
  documentId: true,
  userId: true,
  permission: true,
});

export const insertCommentSchema = createInsertSchema(documentComments).pick({
  documentId: true,
  userId: true,
  content: true,
  position: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type DocumentCollaborator = typeof documentCollaborators.$inferSelect;
export type InsertCollaborator = z.infer<typeof insertCollaboratorSchema>;

export type DocumentComment = typeof documentComments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

// Extended types for API responses
export type DocumentWithCollaborators = Document & {
  owner: User;
  collaborators: (DocumentCollaborator & { user: User })[];
  comments: (DocumentComment & { user: User })[];
};

export type CollaborativeSession = {
  documentId: number;
  activeUsers: {
    user: User;
    cursor?: { line: number; character: number };
    selection?: { start: number; end: number };
  }[];
};
